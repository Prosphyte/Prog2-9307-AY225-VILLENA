import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import javax.swing.Timer;

public class AttendanceTracker extends JFrame {
    
    // UI components for user input and display
    private JTextField attendanceNameField;
    private JTextField courseYearField;
    private JTextField timeInField;
    private JTextField eSignatureField;
    
    public AttendanceTracker() {
        // Configure window properties
        setTitle("Attendance Tracker");
        setSize(650, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create a blank transparent image to remove the icon
        BufferedImage blankImage = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        setIconImage(blankImage);
        
        // Solarized dark color scheme
        Color bg = new Color(0, 43, 54);
        Color fg = new Color(131, 148, 150);
        Color accentBg = new Color(7, 54, 66);
        Color accentFg = new Color(38, 139, 210);
        
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                // Enable antialiasing for smooth rendering
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
        };
        mainPanel.setLayout(new BorderLayout(15, 15));
        mainPanel.setBackground(bg);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header title
        JLabel titleLabel = new JLabel("Attendance Tracker");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(accentFg);
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 15, 15));
        formPanel.setBackground(bg);
        formPanel.setOpaque(false);
        
        // Initialize input fields
        attendanceNameField = createStyledTextField();
        courseYearField = createStyledTextField();
        timeInField = createStyledTextField();
        timeInField.setEditable(false);
        eSignatureField = createStyledTextField();
        eSignatureField.setEditable(false);
        
        // Set initial date/time and generate initial e-signature
        LocalDateTime now = LocalDateTime.now();
        timeInField.setText(now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        eSignatureField.setText("SIG-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        
        // Update time field every second to show live time
        Timer liveTimer = new Timer(1000, e -> {
            timeInField.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        });
        liveTimer.start();
        
        formPanel.add(createStyledLabel("Attendance Name:"));
        formPanel.add(attendanceNameField);
        formPanel.add(createStyledLabel("Course/Year:"));
        formPanel.add(courseYearField);
        formPanel.add(createStyledLabel("Time In:"));
        formPanel.add(timeInField);
        formPanel.add(createStyledLabel("E-Signature:"));
        formPanel.add(eSignatureField);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // Button panel with submit and clear actions
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 0));
        buttonPanel.setBackground(bg);
        buttonPanel.setOpaque(false);
        
        // Submit button - validates input and generates new signature
        buttonPanel.add(createStyledButton("Submit", accentFg, () -> {
            String name = attendanceNameField.getText().trim();
            String course = courseYearField.getText().trim();
            
            // Validate required fields
            if (name.isEmpty() || course.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Generate new signature for this submission
            String newSignature = "SIG-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            eSignatureField.setText(newSignature);
            String message = "Attendance Record Submitted:\nName: " + name + "\nCourse/Year: " + course + 
                           "\nTime In: " + timeInField.getText() + "\nE-Signature: " + newSignature;
            JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
        }));
        
        // Clear button - resets input fields
        buttonPanel.add(createStyledButton("Clear", fg, () -> {
            attendanceNameField.setText("");
            courseYearField.setText("");
        }));
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);
        setVisible(true);
    }
    
    private JLabel createStyledLabel(String text) {
        // Create label with Solarized dark theme styling
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        label.setForeground(new Color(131, 148, 150));
        return label;
    }
    
    private JTextField createStyledTextField() {
        // Custom text field with rounded corners and dark theme
        JTextField field = new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Draw rounded background
                g2d.setColor(new Color(7, 54, 66));
                g2d.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                super.paintComponent(g);
            }
            
            @Override
            protected void paintBorder(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Draw rounded border in accent color
                g2d.setColor(new Color(38, 139, 210));
                g2d.setStroke(new BasicStroke(1.5f));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
            }
        };
        field.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        field.setForeground(new Color(131, 148, 150));
        field.setCaretColor(new Color(38, 139, 210));
        field.setBackground(new Color(7, 54, 66));
        field.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        field.setOpaque(false);
        return field;
    }
    
    private JButton createStyledButton(String text, Color color, Runnable action) {
        // Custom button with rounded corners and dark theme
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Draw rounded background
                g2d.setColor(new Color(7, 54, 66));
                g2d.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                super.paintComponent(g);
            }
            
            @Override
            protected void paintBorder(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Draw rounded border with button color
                g2d.setColor(color);
                g2d.setStroke(new BasicStroke(1.5f));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
            }
        };
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(color);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setPreferredSize(new Dimension(110, 40));
        button.addActionListener(e -> action.run());
        return button;
    }
    
    // Application entry point
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AttendanceTracker());
    }
}
