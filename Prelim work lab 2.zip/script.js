// Predefined credentials for login
const VALID_USERNAME = 'admin';
const VALID_PASSWORD = 'password123';

// Store login data for attendance summary
let attendanceData = {
    username: '',
    timestamp: '',
    course: 'BSCS-1ST YEAR',
    eSignature: '',
    signature: null
};

// Signature canvas variables
let isDrawing = false;
let signatureData = null;

// Get DOM elements
const loginForm = document.getElementById('loginForm');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const messageDiv = document.getElementById('message');
const timestampSection = document.getElementById('timestampSection');
const timestampDisplay = document.getElementById('timestamp');
const courseSection = document.getElementById('courseSection');
const courseDisplay = document.getElementById('courseDisplay');
const eSignatureDisplay = document.getElementById('eSignatureDisplay');
const signatureCanvas = document.getElementById('signatureCanvas');
const clearSignatureBtn = document.getElementById('clearSignatureBtn');
const saveSignatureBtn = document.getElementById('saveSignatureBtn');
const downloadBtn = document.getElementById('downloadBtn');

// Handle login form submission
loginForm.addEventListener('submit', function(e) {
    e.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    // Validate credentials
    if (username === VALID_USERNAME && password === VALID_PASSWORD) {
        // Successful login
        handleSuccessfulLogin(username);
    } else {
        // Failed login - play beeping sound and show error
        handleFailedLogin();
    }
});

// Handle successful login
function handleSuccessfulLogin(username) {
    // Get current system time
    const now = new Date();
    const timestamp = formatTimestamp(now);

    // Generate e-signature in UUID format (matching AttendanceTracker.java format)
    const eSignature = 'SIG-' + generateUUID().substring(0, 8).toUpperCase();

    // Store attendance data
    attendanceData.username = username;
    attendanceData.timestamp = timestamp;
    attendanceData.eSignature = eSignature;

    // Display success message
    messageDiv.textContent = 'Login successful! Welcome, ' + username;
    messageDiv.className = 'message success';

    // Display timestamp and course section
    timestampDisplay.textContent = timestamp;
    eSignatureDisplay.value = eSignature;
    courseDisplay.value = attendanceData.course;
    timestampSection.classList.add('show');
    courseSection.classList.add('show');

    // Hide login form
    loginForm.style.display = 'none';
}

// Generate UUID function matching Java UUID format
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0,
            v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Handle failed login
function handleFailedLogin() {
    // Play beeping sound
    playBeepSound();

    // Display error message
    messageDiv.textContent = 'Login failed! Incorrect username or password.';
    messageDiv.className = 'message error';

    // Clear password field
    passwordInput.value = '';
    passwordInput.focus();
}

// Play custom beep sound when login fails
function playBeepSound() {
    // Create audio element for custom beep sound
    const beepSound = new Audio('beep-warning-6387.mp3');
    beepSound.play()
}

// Initialize signature canvas
function initSignatureCanvas() {
    const ctx = signatureCanvas.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, signatureCanvas.width, signatureCanvas.height);
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
}

// Clear signature canvas
function clearSignatureCanvas() {
    initSignatureCanvas();
    signatureData = null;
}

// Drawing on signature canvas
signatureCanvas.addEventListener('mousedown', (e) => {
    isDrawing = true;
    const rect = signatureCanvas.getBoundingClientRect();
    const ctx = signatureCanvas.getContext('2d');
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
});

signatureCanvas.addEventListener('mousemove', (e) => {
    if (!isDrawing) return;
    const rect = signatureCanvas.getBoundingClientRect();
    const ctx = signatureCanvas.getContext('2d');
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
});

signatureCanvas.addEventListener('mouseup', () => {
    isDrawing = false;
});

signatureCanvas.addEventListener('mouseleave', () => {
    isDrawing = false;
});

// Clear signature button
clearSignatureBtn.addEventListener('click', (e) => {
    e.preventDefault();
    clearSignatureCanvas();
});

// Save signature button
saveSignatureBtn.addEventListener('click', (e) => {
    e.preventDefault();
    signatureData = signatureCanvas.toDataURL('image/png');
    attendanceData.signature = signatureData;
    alert('Signature confirmed successfully!');
});

// Initialize signature canvas on load
initSignatureCanvas();

// Format timestamp to readable format
function formatTimestamp(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
}

// Generate and download attendance summary file
downloadBtn.addEventListener('click', function() {
    // Validate signature
    if (!signatureData) {
        alert('Please confirm your signature first!');
        return;
    }

    // Create attendance summary content
    let summaryContent = 'ATTENDANCE SUMMARY\n' +
                        '==================\n\n' +
                        'Username: ' + attendanceData.username + '\n' +
                        'Login Time: ' + attendanceData.timestamp + '\n' +
                        'Course/Year: ' + attendanceData.course + '\n' +
                        'E-Signature: ' + attendanceData.eSignature + '\n' +
                        'Status: Present\n' +
                        'Signature Confirmed: Yes\n\n' +
                        'Generated on: ' + formatTimestamp(new Date());

    // Create blob from content
    const blob = new Blob([summaryContent], { type: 'text/plain' });

    // Create download link
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = 'attendance_summary_' + attendanceData.username + '_' + attendanceData.eSignature + '.txt';

    // Trigger download
    link.click();

    // Clean up
    window.URL.revokeObjectURL(link.href);
});
