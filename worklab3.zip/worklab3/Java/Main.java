import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainWindow w = new MainWindow();
            w.setVisible(true);
        });
    }

    static class MainWindow extends JFrame {
        private final JTextField attendanceField = new JTextField();
        private final JTextField lab1Field = new JTextField();
        private final JTextField lab2Field = new JTextField();
        private final JTextField lab3Field = new JTextField();
        private final JTextField prelimField = new JTextField();
        private final JTextArea outputArea = new JTextArea();

        private final Color BG = new Color(0x073642);
        private final Color PANEL = new Color(0x002b36);
        private final Color FG = new Color(0x93a1a1);
        private final Color ACCENT = new Color(0x268bd2);
        
        public MainWindow() {
            setTitle("Grade Calculator");
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setSize(520, 420);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout());

            JPanel root = new JPanel(new BorderLayout());
            root.setBackground(BG);
            root.setBorder(new RoundedBorder(16));

            JPanel form = new JPanel();
            form.setBackground(PANEL);
            form.setLayout(new GridBagLayout());
            form.setBorder(BorderFactory.createEmptyBorder(18,18,18,18));

            GridBagConstraints c = new GridBagConstraints();
            c.insets = new Insets(8,8,8,8);
            c.fill = GridBagConstraints.HORIZONTAL;
            c.gridx = 0; c.gridy = 0;
            addLabel(form, "Attendance :", c);
            c.gridx = 1; c.gridy = 0; form.add(styledField(attendanceField), c);

            c.gridx = 0; c.gridy = 1; addLabel(form, "Lab 1 :", c);
            c.gridx = 1; c.gridy = 1; form.add(styledField(lab1Field), c);

            c.gridx = 0; c.gridy = 2; addLabel(form, "Lab 2 :", c);
            c.gridx = 1; c.gridy = 2; form.add(styledField(lab2Field), c);

            c.gridx = 0; c.gridy = 3; addLabel(form, "Lab 3 :", c);
            c.gridx = 1; c.gridy = 3; form.add(styledField(lab3Field), c);

            c.gridx = 0; c.gridy = 4; addLabel(form, "Prelim Exam :", c);
            c.gridx = 1; c.gridy = 4; form.add(styledField(prelimField), c);

            JPanel buttons = new JPanel();
            buttons.setBackground(PANEL);
            RoundButton calc = new RoundButton("Calculate");
            calc.setBackground(ACCENT);
            RoundButton save = new RoundButton("Save CSV");
            save.setBackground(new Color(0x859900));
            buttons.add(calc);
            buttons.add(save);

            c.gridx = 0; c.gridy = 5; c.gridwidth = 2; form.add(buttons, c);

            outputArea.setEditable(false);
            outputArea.setBackground(PANEL);
            outputArea.setForeground(FG);
            outputArea.setBorder(new RoundedBorder(8));
            outputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

            root.add(form, BorderLayout.NORTH);
            root.add(new JScrollPane(outputArea), BorderLayout.CENTER);

            add(root, BorderLayout.CENTER);

            calc.addActionListener(e -> onCalculate());
            save.addActionListener(e -> onSaveCSV());
        }

        private void addLabel(JPanel p, String text, GridBagConstraints c) {
            JLabel l = new JLabel(text);
            l.setForeground(FG);
            p.add(l, c);
        }

        private JComponent styledField(JTextField field) {
            field.setColumns(12);
            field.setBackground(PANEL);
            field.setForeground(FG);
            field.setBorder(new RoundedBorder(8));
            return field;
        }

        private void onCalculate() {
            try {
                double attendance = parseAndValidate(attendanceField.getText().trim(), "Attendance");
                double l1 = parseAndValidate(lab1Field.getText().trim(), "Lab 1");
                double l2 = parseAndValidate(lab2Field.getText().trim(), "Lab 2");
                double l3 = parseAndValidate(lab3Field.getText().trim(), "Lab 3");
                double prelim = parseAndValidate(prelimField.getText().trim(), "Prelim Exam");

                double labworkGrade = labwork(l1, l2, l3);
                double classstandingGrade = classtanding(attendance, labworkGrade);
                double prelimGrade = prelimgrade(prelim, classstandingGrade);

                StringBuilder sb = new StringBuilder();
                sb.append(String.format("Labwork Average: %.2f\n", labworkGrade));
                sb.append(String.format("Class Standing: %.2f\n", classstandingGrade));
                sb.append(String.format("Prelim Grade: %.2f\n", prelimGrade));
                sb.append(prelimGrade >= 75 ? "You passed the course!\n" : "You failed the course.\n");

                outputArea.setText(sb.toString());
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Input error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private double parseAndValidate(String s, String label) {
            if (s.isEmpty()) throw new IllegalArgumentException(label + " is required.");
            double v;
            try {
                v = Double.parseDouble(s);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException(label + " must be a number.");
            }
            if (v < 0 || v > 100) throw new IllegalArgumentException(label + " must be between 0 and 100.");
            return v;
        }

        private void onSaveCSV() {
            if (outputArea.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Calculate results first.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Save grades CSV");
            chooser.setSelectedFile(new File("grades.csv"));
            int returnVal = chooser.showSaveDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                try (FileWriter fw = new FileWriter(file)) {
                    fw.append("Grade,Score\n");
                    String[] lines = outputArea.getText().split("\n");
                    for (String line : lines) {
                        fw.append("\"" + line.replace("\"", "\"\"") + "\"\n");
                    }
                    JOptionPane.showMessageDialog(this, "Saved to " + file.getAbsolutePath());
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error writing CSV: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    public static double labwork(double lab1, double lab2, double lab3) {
        return (lab1 + lab2 + lab3) / 3.0;
    }

    public static double classtanding(double attendance, double labwork) {
        return (attendance * 0.40) + (labwork * 0.60);
    }

    public static double prelimgrade(double prelimgexam, double classtanding) {
        return (prelimgexam * 0.70) + (classtanding * 0.30);
    }

    static class RoundedBorder extends AbstractBorder {
        private final int radius;
        public RoundedBorder(int r) { radius = r; }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0,0,0,80));
            g2.drawRoundRect(x, y, width-1, height-1, radius, radius);
            g2.dispose();
        }
    }

    static class RoundButton extends JButton {
        public RoundButton(String text) {
            super(text);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setForeground(Color.WHITE);
            setPreferredSize(new Dimension(120, 32));
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
            super.paintComponent(g2);
            g2.dispose();
        }
        @Override
        public void setContentAreaFilled(boolean b) { /* ignore */ }
    }
}